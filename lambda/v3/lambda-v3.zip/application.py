def handler(event, context):
    raise Exception("Oops! Canary failed!")  # simulate failure